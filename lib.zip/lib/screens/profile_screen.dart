import 'package:flutter/material.dart';
import 'edit_profile_screen.dart';
import 'scan_qr_screen.dart';
import 'package:qr_flutter/qr_flutter.dart';

class ProfileScreen extends StatelessWidget {
  final String? username;

  const ProfileScreen({super.key, this.username});

  @override
  Widget build(BuildContext context) {
    // Username mặc định nếu không được truyền vào
    final String displayUsername = username ?? '@TranDuyDan_204';

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFAFEEEE), // Màu gradient trên
              Color(0xFF920A92), // Màu gradient dưới
            ],
          ),
        ),
        child: SafeArea(
          child: CustomScrollView(
            slivers: [
              // TopBar
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () {
                          Navigator.pop(context); // Quay lại Home
                        },
                      ),
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.camera_alt, color: Colors.white),
                            onPressed: () {
                              // Xử lý mở camera (chưa triển khai)
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const ScanQRScreen(),
                                ),
                              );
                            },
                          ),
                          // Icon QR (tạo QR)
                          IconButton(
                            icon: const Icon(Icons.qr_code, color: Colors.white),
                            onPressed: () {
                              _showQRCodeDialog(context, displayUsername);
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              // Nội dung chính
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      // Avatar
                      const CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.white,
                        child: Icon(
                          Icons.person,
                          size: 50,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Thông tin người dùng
                      const Text(
                        'Tran Duy Dan',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const Text(
                        '@TranDuyDan204',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white70,
                        ),
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const EditProfileScreen(),
                            ),
                          );
                        },
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.white),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'edit profile',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(width: 5),
                            Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 16,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Số liệu (Playlists, Linking apps, Followers, Following)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildStatColumn('12', 'playlists'),
                          _buildStatColumn('4', 'linking apps'),
                          _buildStatColumn('108', 'followers'),
                          _buildStatColumn('59', 'following'),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // Đường kẻ ngang phân cách
                      const Divider(
                        color: Colors.white70,
                        thickness: 1,
                        indent: 20,
                        endIndent: 20,
                      ),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ),

              // Danh sách ảnh
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 0.8,
                  ),
                  delegate: SliverChildListDelegate([
                    _buildImageCard('https://picsum.photos/150', 'sad soul<3'),
                    _buildImageCard('https://picsum.photos/150?random=1', '> uwu <'),
                    _buildImageCard('https://picsum.photos/150?random=2', 'Richie <3'),
                    _buildImageCard('https://picsum.photos/150?random=3', ''),
                    _buildImageCard('https://picsum.photos/150?random=4', ''),
                    _buildImageCard('https://picsum.photos/150?random=5', 'good vibes'),
                  ]),
                ),
              ),

              // Thêm padding động để tránh tràn pixel
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).padding.bottom + 100,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      // BottomBar
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF60135E),
        selectedItemColor: Color(0xFFAFEEEE),
        unselectedItemColor: Colors.white70,
        type: BottomNavigationBarType.fixed,
        currentIndex: 3, // Chọn tab Profile
        onTap: (index) {
          if (index == 0) {
            Navigator.pop(context); // Quay lại Home
          } else if (index == 1) {
            Navigator.pop(context); // Chuyển sang trang browse 
          } else if (index == 2) {
            Navigator.pushNamed(context, '/library'); // Chuyển sang trang library
          } else if (index == 4) {
            Navigator.pushNamed(context, '/setting');
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.apps),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.library_music),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: '',
          ),
        ],
      ),
    );
  }

  // Widget cho cột số liệu
  Widget _buildStatColumn(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.white70,
          ),
        ),
      ],
    );
  }

  // Widget cho ảnh trong grid
  Widget _buildImageCard(String imageUrl, String label) {
    return Column(
      children: [
        Container(
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            image: DecorationImage(
              image: NetworkImage(imageUrl),
              fit: BoxFit.cover,
              onError: (exception, stackTrace) {
                print('Error loading image: $exception');
              },
            ),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          label,
          style: const TextStyle(color: Colors.white),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // Hàm hiển thị dialog chứa mã QR
void _showQRCodeDialog(BuildContext context, String username) {
  showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: const Color(0xFF920A92),
        title: const Text(
          'Your Profile QR Code',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.8, // Giới hạn chiều rộng tối đa
            maxHeight: MediaQuery.of(context).size.height * 0.5, // Giới hạn chiều cao tối đa
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 200, // Đặt kích thước cố định cho QrImage
                  height: 200,
                  child: QrImageView(
                    data: username, // Dữ liệu mã QR (username)
                    version: QrVersions.auto,
                    backgroundColor: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Scan this QR code to visit $username',
                  style: const TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text(
              'Close',
              style: TextStyle(color: Colors.white70),
            ),
          ),
        ],
      );
    },
  );
}
}