import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'dart:async';
import 'a_song_share_link_screen.dart';

class ASongScreen extends StatefulWidget {
  final String? title;
  final String? artist;
  final String? audioUrl;
  final List<Map<String, dynamic>>? lyrics;

  const ASongScreen({
    super.key,
    this.title,
    this.artist,
    this.audioUrl,
    this.lyrics,
  });

  @override
  _ASongScreenState createState() => _ASongScreenState();
}

class _ASongScreenState extends State<ASongScreen> {
  late AudioPlayer _audioPlayer;
  int _currentLyricIndex = -1;
  bool _isPlaying = false;
  bool _isLooping = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  // Dữ liệu bài hát
  late String title;
  late String artist;
  late String audioUrl;
  late List<Map<String, dynamic>> lyrics;

  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isInitialized) {
      // Lấy tham số từ arguments
      final arguments = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>?;
      title = arguments?['title'] ?? widget.title ?? 'Unknown Title';
      artist = arguments?['artist'] ?? widget.artist ?? 'Unknown Artist';
      audioUrl = arguments?['audioUrl'] ?? widget.audioUrl ?? '';
      lyrics = arguments?['lyrics'] ?? widget.lyrics ?? [];

      _initAudioPlayer();
      _isInitialized = true;
    }
  }

  Future<void> _initAudioPlayer() async {
    try {
      await _audioPlayer.setUrl(audioUrl);
      _audioPlayer.positionStream.listen((position) {
        setState(() {
          _position = position;
          _updateCurrentLyric(position);
        });
      });
      _audioPlayer.durationStream.listen((duration) {
        setState(() {
          _duration = duration ?? Duration.zero;
        });
      });
      _audioPlayer.playerStateStream.listen((state) {
        setState(() {
          _isPlaying = state.playing;
        });
      });
    } catch (e) {
      print('Error loading audio: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading audio: $e')),
        );
      }
    }
  }

  void _updateCurrentLyric(Duration position) {
    int newIndex = -1;
    for (int i = 0; i < lyrics.length; i++) {
      final lyricTime = lyrics[i]['time'];
      if (position.inMilliseconds >= lyricTime) {
        newIndex = i;
      } else {
        break;
      }
    }
    if (newIndex != _currentLyricIndex) {
      setState(() {
        _currentLyricIndex = newIndex;
      });
    }
  }

  void _togglePlayPause() {
    if (_isPlaying) {
      _audioPlayer.pause();
    } else {
      _audioPlayer.play();
    }
  }

  void _seekBackward() {
    final newPosition = _position - const Duration(seconds: 10);
    _audioPlayer.seek(newPosition < Duration.zero ? Duration.zero : newPosition);
  }

  void _seekForward() {
    final newPosition = _position + const Duration(seconds: 10);
    _audioPlayer.seek(newPosition > _duration ? _duration : newPosition);
  }

  void _toggleLoop() {
    setState(() {
      _isLooping = !_isLooping;
      _audioPlayer.setLoopMode(_isLooping ? LoopMode.one : LoopMode.off);
    });
  }

  void _shareSong() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ASongShareLinkScreen(
          title: title,
          artist: artist,
          shareUrl: 'https://example.com/song/$title',
        ),
      ),
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFAFEEEE), // Màu gradient trên
              Color(0xFF920A92), // Màu gradient dưới
            ],
          ),
        ),
        child: SafeArea(
          child: CustomScrollView(
            slivers: [
              // TopBar
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.arrow_back_ios,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.pop(context); // Quay lại playlist
                        },
                      ),
                      const Expanded(
                        child: Text(
                          'Bài hát',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(
                          Icons.share,
                          color: Colors.white,
                        ),
                        onPressed: _shareSong, // Điều hướng đến màn hình chia sẻ
                      ),
                    ],
                  ),
                ),
              ),

              // Lời bài hát
              SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  height: 300, // Chiều cao cố định cho khu vực lời bài hát
                  child: ListView.builder(
                    itemCount: lyrics.length,
                    itemBuilder: (context, index) {
                      final lyric = lyrics[index]['text'];
                      final isCurrent = index == _currentLyricIndex;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5.0),
                        child: Text(
                          lyric,
                          style: TextStyle(
                            color: isCurrent ? Colors.pink[400] : Colors.white70,
                            fontSize: 16,
                            fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      );
                    },
                  ),
                ),
              ),

              // Thanh điều khiển
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  child: Column(
                    children: [
                      // Thanh tiến trình
                      Slider(
                        activeColor: Colors.pink[400],
                        inactiveColor: Colors.white70,
                        value: _position.inSeconds.toDouble(),
                        max: _duration.inSeconds.toDouble(),
                        onChanged: (value) {
                          _audioPlayer.seek(Duration(seconds: value.toInt()));
                        },
                      ),
                      // Thông tin bài hát
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        artist,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 10),
                      // Nút điều khiển
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.replay_10, color: Colors.white),
                            onPressed: _seekBackward,
                          ),
                          IconButton(
                            icon: Icon(
                              _isPlaying ? Icons.pause : Icons.play_arrow,
                              color: Colors.white,
                              size: 40,
                            ),
                            onPressed: _togglePlayPause,
                          ),
                          IconButton(
                            icon: const Icon(Icons.forward_10, color: Colors.white),
                            onPressed: _seekForward,
                          ),
                          IconButton(
                            icon: Icon(
                              Icons.repeat,
                              color: _isLooping ? Colors.pink[400] : Colors.white,
                            ),
                            onPressed: _toggleLoop,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              // Thêm padding động để tránh tràn pixel
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).padding.bottom + 100,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      // BottomBar
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF60135E),
        selectedItemColor: Color(0xFFAFEEEE),
        unselectedItemColor: Colors.white70,
        type: BottomNavigationBarType.fixed,
        currentIndex: 2, // Chọn tab Library
        onTap: (index) {
          if (index == 0) {
            Navigator.pushNamed(context, '/home');
          } else if (index == 1) {
            Navigator.pushNamed(context, '/browse');
          } else if (index == 3) {
            Navigator.pushNamed(context, '/profile');
          } else if (index == 4) {
            Navigator.pushNamed(context, '/setting');
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.apps),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.library_music),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: '',
          ),
        ],
      ),
    );
  }
}