import 'package:flutter/material.dart';
import 'playlist_screen.dart';

class BrowseScreen extends StatelessWidget {
  const BrowseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Thêm Drawer vào Scaffold
      drawer: Drawer(
        child: Container(
          color: const Color(0xFF920A92), // Nền Drawer khớp với gradient dưới
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Color(0xFFAFEEEE), // Nền header khớp với gradient trên
                ),
                child: Text(
                  'Menu',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.home, color: Colors.white),
                title: const Text('Trang chủ', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context); // Đóng Drawer
                  Navigator.pushNamed(context, '/home');
                },
              ),
              ListTile(
                leading: const Icon(Icons.person, color: Colors.white),
                title: const Text('Hồ sơ', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/profile');
                },
              ),
              ListTile(
                leading: const Icon(Icons.qr_code_scanner, color: Colors.white),
                title: const Text('Quét mã QR', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/scan_qr');
                },
              ),
              ListTile(
                leading: const Icon(Icons.settings, color: Colors.white),
                title: const Text('Cài đặt', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/setting');
                },
              ),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.white),
                title: const Text('Đăng xuất', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Đã đăng xuất')),
                  );
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    '/signup',
                    (route) => false, // Xóa toàn bộ stack điều hướng
                  );
                },
              ),
            ],
          ),
        ),
      ),

      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFAFEEEE), // Màu gradient trên
              Color(0xFF920A92), // Màu gradient dưới

            ],
          ),
        ),
        child: SafeArea(
          child: CustomScrollView(
            slivers: [
              // TopBar
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Nút menu (sử dụng IconButton và Builder để mở Drawer)
                      Builder(
                        builder: (context) => IconButton(
                          icon: const Icon(
                            Icons.menu,
                            color: Colors.white,
                          ),
                          onPressed: () {
                            Scaffold.of(context).openDrawer(); // Mở Drawer
                          },
                        ),
                      ),
                      Container(
                        width: 200,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const TextField(
                          decoration: InputDecoration(
                            hintText: 'Search',
                            hintStyle: TextStyle(color: Colors.white70),
                            border: InputBorder.none,
                            prefixIcon: Icon(
                              Icons.search,
                              color: Colors.white,
                            ),
                          ),
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushNamed(context, '/profile');
                        },
                        child: const CircleAvatar(
                          radius: 15,
                          backgroundColor: Colors.transparent,
                          child: Icon(
                            Icons.account_circle_outlined,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Nội dung chính
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 20),

                      // Popular genres
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Popular genres',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFFF4081),
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              _showViewAllDialog(context, 'Popular genres', [
                                'Pop',
                                'Hip hop',
                                'Classical',
                                'Jazz',
                                'EDM',
                                'Blue',
                                'R&B',
                                'Indie',
                                'Rock',
                                'Country',
                              ]);
                            },
                            child: const Text(
                              'View all',
                              style: TextStyle(color: Colors.white70),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      GridView.count(
                        crossAxisCount: 4,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        childAspectRatio: 0.8,
                        children: [
                          _buildGenreCard('Pop', 'https://picsum.photos/150?random=1'),
                          _buildGenreCard('Hip hop', 'https://picsum.photos/150?random=2'),
                          _buildGenreCard('Classical', 'https://picsum.photos/150?random=3'),
                          _buildGenreCard('Jazz', 'https://picsum.photos/150?random=4'),
                          _buildGenreCard('EDM', 'https://picsum.photos/150?random=5'),
                          _buildGenreCard('Blue', 'https://picsum.photos/150?random=6'),
                          _buildGenreCard('R&B', 'https://picsum.photos/150?random=7'),
                          _buildGenreCard('Indie', 'https://picsum.photos/150?random=8'),
                        ],
                      ),
                      const SizedBox(height: 30),

                      // Daily recommendations
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Daily recommendations',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFFF4081),
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              _showViewAllDialog(context, 'Daily recommendations', [
                                'Workout monster',
                                'Productivity 101',
                                'Morning vibes',
                                'Chill hits',
                              ]);
                            },
                            child: const Text(
                              'View all',
                              style: TextStyle(color: Colors.white70),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Column(
                        children: [
                          _buildPlaylistItem(
                            context, // Truyền context vào
                            'Workout monster',
                            'https://picsum.photos/150?random=9',
                            [
                              {'title': 'Song 1', 'artist': 'Artist 1', 'platform': 'Spotify'},
                              {'title': 'Song 2', 'artist': 'Artist 2', 'platform': 'YouTube'},
                            ],
                          ),
                          _buildPlaylistItem(
                            context, // Truyền context vào
                            'Productivity 101',
                            'https://picsum.photos/150?random=10',
                            [
                              {'title': 'Never Gonna Give You Up', 'artist': 'Rick Astley', 'platform': 'Spotify'},
                              {'title': 'Boom', 'artist': 'Tiesto, Seven', 'platform': 'YouTube'},
                              {'title': 'Cigarette', 'artist': 'offonoff', 'platform': 'Spotify'},
                              {'title': 'Can\'t get you out of my head', 'artist': 'Khalid', 'platform': 'YouTube'},
                              {'title': 'Love Story', 'artist': 'Taylor Swift', 'platform': 'Spotify'},
                              {'title': 'Nocturne Op. 9 No. 2', 'artist': 'Chopin', 'platform': 'YouTube'},
                              {'title': 'Bigcityboi', 'artist': 'Binz', 'platform': 'Spotify'},
                              {'title': 'Anysong', 'artist': 'Zico', 'platform': 'YouTube'},
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 30),

                      // New releases
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'New releases',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFFF4081),
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              _showViewAllDialog(context, 'New releases', [
                                'This is Ed Sheeran',
                                'Speak Now',
                                'Midnight Marauders',
                                'Evermore',
                              ]);
                            },
                            child: const Text(
                              'View all',
                              style: TextStyle(color: Colors.white70),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Column(
                        children: [
                          _buildPlaylistItem(
                            context, // Truyền context vào
                            'This is Ed Sheeran',
                            'https://picsum.photos/150?random=11',
                            [
                              {'title': 'Song 3', 'artist': 'Ed Sheeran', 'platform': 'Spotify'},
                              {'title': 'Song 4', 'artist': 'Ed Sheeran', 'platform': 'YouTube'},
                            ],
                          ),
                          _buildPlaylistItem(
                            context, // Truyền context vào
                            'Speak Now',
                            'https://picsum.photos/150?random=12',
                            [
                              {'title': 'Song 5', 'artist': 'Taylor Swift', 'platform': 'Spotify'},
                              {'title': 'Song 6', 'artist': 'Taylor Swift', 'platform': 'YouTube'},
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 50),
                    ],
                  ),
                ),
              ),

              // Thêm padding động để tránh tràn pixel
              SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).padding.bottom + 100,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      // BottomBar
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: const Color(0xFF60135E),
        selectedItemColor: Color(0xFFAFEEEE),
        unselectedItemColor: Colors.white70,
        type: BottomNavigationBarType.fixed,
        currentIndex: 1, // Chọn tab Browse
        onTap: (index) {
          if (index == 0) {
            Navigator.pushNamed(context, '/home');
          } else if (index == 2) {
            Navigator.pushNamed(context, '/library');
          } else if (index == 3) {
            Navigator.pushNamed(context, '/profile');
          } else if (index == 4) {
            Navigator.pushNamed(context, '/setting');
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.apps),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.library_music),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: '',
          ),
        ],
      ),
    );
  }

  // Widget cho thẻ thể loại (Popular genres)
  Widget _buildGenreCard(String title, String imageUrl) {
    return Column(
      children: [
        Container(
          height: 60,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            image: DecorationImage(
              image: NetworkImage(imageUrl),
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          title,
          style: const TextStyle(color: Colors.white, fontSize: 12),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  // Widget cho mục playlist (Daily recommendations, New releases)
  Widget _buildPlaylistItem(
    BuildContext context, // Thêm tham số context
    String title,
    String imageUrl,
    List<Map<String, String>> songs,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: GestureDetector(
        onTap: () {
          // Điều hướng đến PlaylistScreen
          Navigator.push(
            context, // Sử dụng context đã truyền vào
            MaterialPageRoute(
              builder: (context) => PlaylistScreen(
                playlistName: title,
                songs: songs,
              ),
            ),
          );
        },
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  image: DecorationImage(
                    image: NetworkImage(imageUrl),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
              const Icon(
                Icons.play_arrow,
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Hàm hiển thị dialog "View all"
  void _showViewAllDialog(BuildContext context, String title, List<String> items) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF920A92),
          title: Text(
            title,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: items.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(
                    items[index],
                    style: const TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text(
                'Close',
                style: TextStyle(color: Colors.white70),
              ),
            ),
          ],
        );
      },
    );
  }
}