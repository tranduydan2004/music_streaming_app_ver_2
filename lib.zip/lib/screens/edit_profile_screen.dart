import 'package:flutter/material.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  bool isPublic = true; // Trạng thái Account mode (Public/Private)
  bool showStats = true; // Trạng thái Interaction statistics (Show/Hide)

  // TextEditingController để theo dõi giá trị các trường
  final TextEditingController usernameController = TextEditingController(text: 'TranDuyDan204');
  final TextEditingController firstNameController = TextEditingController(text: 'Dan');
  final TextEditingController lastNameController = TextEditingController(text: 'Tran Duy');
  final TextEditingController pronounsController = TextEditingController(text: 'Pronouns');

  // Danh sách giả lập các username đã tồn tại
  final List<String> existingUsernames = [
    'User123',
    'JohnDoe',
    'JaneSmith',
    'TranDuyDan204', // Username hiện tại của người dùng
    'TestUser',
  ];

  @override
  void dispose() {
    usernameController.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    pronounsController.dispose();
    super.dispose();
  }

  // Hàm kiểm tra username và hiển thị thông báo lỗi nếu trùng
  void _checkUsernameAndSave(BuildContext context) {
    String newUsername = usernameController.text.trim();

    // Kiểm tra xem username mới có trùng với username đã tồn tại hay không
    // (trừ username hiện tại của người dùng)
    if (existingUsernames.contains(newUsername) && newUsername != 'TranDuyDan204') {
      // Hiển thị SnackBar thông báo lỗi
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: Colors.red,
          content: const Row(
            children: [
              Icon(
                Icons.error,
                color: Colors.white,
              ),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'This username is not available. Please try another.',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          duration: const Duration(seconds: 3),
        ),
      );
    } else {
      // Nếu username hợp lệ, lưu thông tin và quay lại
      // (Logic lưu thông tin chưa triển khai, chỉ quay lại màn hình trước)
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFAFEEEE), // Màu gradient trên
              Color(0xFF920A92), // Màu gradient dưới
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // TopBar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white),
                      onPressed: () {
                        Navigator.pop(context); // Hủy và quay lại Profile
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.check, color: Colors.white),
                      onPressed: () {
                        _checkUsernameAndSave(context); // Kiểm tra username và lưu
                      },
                    ),
                  ],
                ),
              ),

              // Nội dung chính
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 20),
                        // Avatar
                        Center(
                          child: Stack(
                            children: [
                              const CircleAvatar(
                                radius: 50,
                                backgroundColor: Colors.white,
                                child: Icon(
                                  Icons.person,
                                  size: 50,
                                  color: Colors.black,
                                ),
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: Container(
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.white,
                                  ),
                                  child: const Icon(
                                    Icons.camera_alt,
                                    color: Colors.black,
                                    size: 20,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 30),

                        // Trường nhập liệu
                        _buildTextField('Username', usernameController),
                        const SizedBox(height: 20),
                        _buildTextField('First name', firstNameController),
                        const SizedBox(height: 20),
                        _buildTextField('Last name', lastNameController),
                        const SizedBox(height: 20),
                        _buildTextField('Pronouns', pronounsController),
                        const SizedBox(height: 30),

                        // Account mode
                        const Text(
                          'Account mode',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            _buildToggleButton(
                              'Public',
                              isPublic,
                              () {
                                setState(() {
                                  isPublic = true;
                                });
                              },
                            ),
                            const SizedBox(width: 10),
                            _buildToggleButton(
                              'Private',
                              !isPublic,
                              () {
                                setState(() {
                                  isPublic = false;
                                });
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 30),

                        // Interaction statistics
                        const Text(
                          'Interaction statistics',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            _buildToggleButton(
                              'Show',
                              showStats,
                              () {
                                setState(() {
                                  showStats = true;
                                });
                              },
                            ),
                            const SizedBox(width: 10),
                            _buildToggleButton(
                              'Hide',
                              !showStats,
                              () {
                                setState(() {
                                  showStats = false;
                                });
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 50),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Widget cho trường nhập liệu
  Widget _buildTextField(String label, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 5),
        TextField(
          controller: controller,
          decoration: InputDecoration(
            hintStyle: const TextStyle(color: Colors.white70),
            filled: true,
            fillColor: Colors.white.withOpacity(0.2),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
          style: const TextStyle(color: Colors.white),
        ),
      ],
    );
  }

  // Widget cho nút toggle
  Widget _buildToggleButton(String label, bool isSelected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white.withOpacity(0.3) : Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white70,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}