import 'package:flutter/material.dart';
import 'package:music_streaming_app/screens/browse_screen.dart';
import 'package:music_streaming_app/screens/library_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/signin_screen.dart';
import 'screens/login_success_screen.dart';
import 'screens/home_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/support_screen.dart';
import 'screens/upload_track_screen.dart';
import 'screens/playlist_screen.dart';
import 'screens/scan_qr_screen.dart';
import 'screens/by_resources_screen.dart';
import 'screens/audio_app_detail_screen.dart';
import 'screens/a_song_screen.dart';
import 'screens/a_song_share_link_screen.dart';
import 'screens/settings_screen.dart';

void main() {
  runApp(const MusicStreamingApp());
}

class MusicStreamingApp extends StatelessWidget {
  const MusicStreamingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DNAHUABRACA',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      initialRoute: '/signup',
      routes: {
        '/signup': (context) => const SignUpScreen(),
        '/signin': (context) => const SignInScreen(),
        '/login_success': (context) => const LoginSuccessScreen(),
        '/home': (context) => const HomeScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/support': (context) => const SupportScreen(),
        '/browse': (context) => const BrowseScreen(),
        '/library': (context) => const LibraryScreen(),
        '/upload': (context) => const UploadTrackScreen(),
        '/playlist': (context) => const PlaylistScreen(
          playlistName: 'Default Playlist',
          songs: []
          ), // Route mặc định (sẽ được thay thế khi điều hướng từ BrowseScreen)
        '/scan_qr': (context) => const ScanQRScreen(),
        '/by_resources': (context) => const ByResourcesScreen(),
        '/a_song': (context) => const ASongScreen(
          title: '',
          artist: '',
          audioUrl: '',
          lyrics: []
          ),
        '/a_song_share_link': (context) => const ASongShareLinkScreen(
          title: '',
          artist: '',
          shareUrl: ''
          ),
        '/setting': (context) => const SettingsScreen(),
      },
    );
  }
}